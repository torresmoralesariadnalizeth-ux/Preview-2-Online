import React, { useState, useRef, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Music,
  Video,
  UploadCloud,
  Download,
  RotateCcw,
  Sparkles,
  FileCheck,
  AlertCircle,
  FileAudio,
  FileVideo,
  Play,
  Layers,
  Sliders,
  CheckCircle2,
  Clock,
  HardDrive,
  Info,
} from 'lucide-react';
import FormulaCards from './components/FormulaCards';
import MediaPreview from './components/MediaPreview';
import { TargetType, PitchMode, ConvertedJob } from './types';
import { createDemoAudioFile } from './utils/audioDemo';

export default function App() {
  // Step 1: Target type (first question: Video or Audio)
  const [targetType, setTargetType] = useState<TargetType>('audio');
  const [pitchMode, setPitchMode] = useState<PitchMode>('rubberband');

  // Step 2: File state
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileObjectUrl, setFileObjectUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Conversion state
  const [isConverting, setIsConverting] = useState(false);
  const [conversionProgress, setConversionProgress] = useState(0);
  const [progressStage, setProgressStage] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Completed job
  const [latestJob, setLatestJob] = useState<ConvertedJob | null>(null);
  const [conversionHistory, setConversionHistory] = useState<ConvertedJob[]>([]);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      if (fileObjectUrl) URL.revokeObjectURL(fileObjectUrl);
    };
  }, [fileObjectUrl]);

  // Handle file selection
  const handleFileSelect = (file: File) => {
    if (fileObjectUrl) {
      URL.revokeObjectURL(fileObjectUrl);
    }
    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setFileObjectUrl(url);
    setErrorMsg(null);
    setLatestJob(null);

    // Smart suggestion if user hasn't actively locked choice:
    const isVideoFile = file.type.startsWith('video/') || /\.(mp4|mkv|mov|avi|webm|flv|wmv|ts)$/i.test(file.name);
    if (isVideoFile && targetType === 'audio') {
      // Keep audio if user wants audio, but let them know or auto-switch
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  // Quick demo sample loader
  const handleLoadDemo = () => {
    const demo = createDemoAudioFile();
    handleFileSelect(demo);
  };

  // Convert action
  const handleConvert = async () => {
    if (!selectedFile) {
      setErrorMsg('Por favor selecciona un archivo con audio antes de convertir.');
      return;
    }

    setIsConverting(true);
    setErrorMsg(null);
    setConversionProgress(10);
    setProgressStage('Subiendo archivo multimedia...');

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('targetType', targetType);
      formData.append('pitchMode', pitchMode);

      // Visual progress increments while processing
      const progressTimer = setInterval(() => {
        setConversionProgress((prev) => {
          if (prev >= 90) return prev;
          if (prev < 30) {
            setProgressStage('Analizando pistas de audio y video...');
            return prev + 15;
          }
          if (prev < 60) {
            setProgressStage('Generando repeticiones: pitches +1, -2, +1 y flip horizontal...');
            return prev + 12;
          }
          if (prev < 85) {
            setProgressStage(
              targetType === 'audio'
                ? 'Concatenando sin fade y codificando en FLAC...'
                : 'Renderizando video con flip y codificando en MP4...'
            );
            return prev + 8;
          }
          return prev + 2;
        });
      }, 500);

      const response = await fetch('/api/convert', {
        method: 'POST',
        body: formData,
      });

      clearInterval(progressTimer);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Error en el servidor: HTTP ${response.status}`);
      }

      const result = await response.json();
      setConversionProgress(100);
      setProgressStage('¡Conversión completada! Iniciando descarga...');

      const newJob: ConvertedJob = {
        jobId: result.jobId,
        outputName: result.outputName,
        targetType: result.targetType,
        sizeBytes: result.sizeBytes,
        durationSeconds: result.durationSeconds,
        downloadUrl: result.downloadUrl,
        previewUrl: result.previewUrl,
        createdAt: Date.now(),
        originalName: selectedFile.name,
        details: result.details,
      };

      setLatestJob(newJob);
      setConversionHistory((prev) => [newJob, ...prev]);

      // Confetti celebratory burst
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: targetType === 'audio' ? ['#10b981', '#06b6d4', '#3b82f6'] : ['#8b5cf6', '#ec4899', '#f59e0b'],
      });

      // Auto-trigger download
      triggerDownload(newJob.downloadUrl, newJob.outputName);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Ocurrió un error inesperado al convertir el archivo.');
    } finally {
      setIsConverting(false);
    }
  };

  // Helper to trigger browser download
  const triggerDownload = (url: string, filename: string) => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return 'Desconocida';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const isVideoInput =
    selectedFile &&
    (selectedFile.type.startsWith('video/') ||
      /\.(mp4|mkv|mov|avi|webm|flv|wmv|ts)$/i.test(selectedFile.name));

  return (
    <div className="min-h-screen bg-[#090a0f] text-neutral-100 flex flex-col justify-between selection:bg-emerald-500 selection:text-black">
      {/* Background ambient decorative glows */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-emerald-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-fuchsia-600/10 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto w-full px-4 sm:px-6 py-8">
        {/* Top Header */}
        <header className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-neutral-900 border border-neutral-800 text-xs font-mono font-medium text-emerald-400 mb-4 shadow-inner">
            <Sparkles className="w-3.5 h-3.5" />
            <span>PREVIEW 2 EFFECT CONVERTER</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-white mb-3">
            Convertir a{' '}
            <span className="bg-gradient-to-r from-emerald-400 via-cyan-400 to-fuchsia-400 bg-clip-text text-transparent">
              Preview 2
            </span>
          </h1>

          <p className="max-w-2xl mx-auto text-neutral-400 text-sm sm:text-base leading-relaxed">
            Importa cualquier archivo multimedia con audio sin restricciones. Transforma tu archivo en la
            secuencia clásica cuádruple de pitches con flip horizontal y descarga inmediata en{' '}
            <span className="text-emerald-400 font-semibold">FLAC</span> (audio) o{' '}
            <span className="text-cyan-400 font-semibold">MP4</span> (video).
          </p>
        </header>

        {/* Explanation Section */}
        <div className="mb-8">
          <FormulaCards />
        </div>

        {/* Main interactive workflow */}
        <div className="space-y-8">
          {/* STEP 1: Question - Video or Audio? */}
          <section className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
            <div className="flex items-center gap-2 mb-4">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500 text-black text-xs font-bold font-mono">
                1
              </span>
              <h2 className="text-lg font-bold text-neutral-100">
                Primero: ¿Es Video o Audio?
              </h2>
            </div>

            <p className="text-xs text-neutral-400 mb-4">
              Selecciona el tipo de salida que deseas. Si es audio se descargará como{' '}
              <strong className="text-emerald-400 font-mono">.FLAC</strong> y si es video se exportará como{' '}
              <strong className="text-cyan-400 font-mono">.MP4</strong> con efecto visual de flip horizontal.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Option: Audio */}
              <button
                type="button"
                onClick={() => setTargetType('audio')}
                className={`relative flex flex-col p-5 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                  targetType === 'audio'
                    ? 'bg-emerald-950/30 border-emerald-500/80 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500/50'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/40'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                    <Music className="w-6 h-6" />
                  </div>
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-mono font-semibold ${
                      targetType === 'audio'
                        ? 'bg-emerald-500 text-black font-bold'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    Exporta .FLAC
                  </span>
                </div>

                <div className="text-lg font-bold text-neutral-100 mb-1">
                  🎵 Formato Audio
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Audio puro en calidad <strong className="text-neutral-200">FLAC Lossless</strong> sin compresión destructiva.
                  Aplica la fórmula de 4 repeticiones de pitches sin pausa continua.
                </p>
                {targetType === 'audio' && (
                  <div className="mt-3 flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Modo Audio seleccionado</span>
                  </div>
                )}
              </button>

              {/* Option: Video */}
              <button
                type="button"
                onClick={() => setTargetType('video')}
                className={`relative flex flex-col p-5 rounded-xl border text-left transition-all duration-200 cursor-pointer ${
                  targetType === 'video'
                    ? 'bg-cyan-950/30 border-cyan-500/80 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-500/50'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700 hover:bg-neutral-900/40'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                    <Video className="w-6 h-6" />
                  </div>
                  <span
                    className={`text-xs px-2.5 py-1 rounded-full font-mono font-semibold ${
                      targetType === 'video'
                        ? 'bg-cyan-500 text-black font-bold'
                        : 'bg-neutral-800 text-neutral-400'
                    }`}
                  >
                    Exporta .MP4
                  </span>
                </div>

                <div className="text-lg font-bold text-neutral-100 mb-1">
                  🎥 Formato Video
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Video renderizado en <strong className="text-neutral-200">MP4 (H.264 + AAC)</strong> con inversión horizontal{' '}
                  <span className="text-cyan-300 font-medium">(flip)</span> en repeticiones 2 y 4, sincronizado con los pitches.
                </p>
                {targetType === 'video' && (
                  <div className="mt-3 flex items-center gap-1.5 text-xs text-cyan-400 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Modo Video seleccionado</span>
                  </div>
                )}
              </button>
            </div>
          </section>

          {/* STEP 2: Import any file without restriction */}
          <section className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500 text-black text-xs font-bold font-mono">
                  2
                </span>
                <h2 className="text-lg font-bold text-neutral-100">
                  Importar archivo (Sin restricciones de formato)
                </h2>
              </div>

              <button
                type="button"
                onClick={handleLoadDemo}
                className="text-xs text-neutral-400 hover:text-emerald-400 flex items-center gap-1 transition-colors font-medium cursor-pointer"
                title="Cargar un archivo de audio sintetizado de prueba"
              >
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                <span>Usar archivo de prueba</span>
              </button>
            </div>

            {/* Drop zone */}
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onClick={() => fileInputRef.current?.click()}
              className={`relative flex flex-col items-center justify-center p-8 rounded-xl border-2 border-dashed cursor-pointer transition-all duration-200 ${
                isDragging
                  ? 'border-emerald-400 bg-emerald-500/10 scale-[1.01]'
                  : 'border-neutral-800 hover:border-neutral-700 bg-neutral-950/40 hover:bg-neutral-950/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept="*/*"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />

              <div className="w-14 h-14 rounded-2xl bg-neutral-800/80 border border-neutral-700 flex items-center justify-center text-emerald-400 mb-3 shadow-inner">
                <UploadCloud className="w-7 h-7" />
              </div>

              <div className="text-center">
                <p className="text-sm font-semibold text-neutral-200 mb-1">
                  Haz clic o arrastra cualquier archivo aquí
                </p>
                <p className="text-xs text-neutral-500">
                  Acepta cualquier extensión con audio: MP4, MKV, AVI, MOV, WEBM, MP3, WAV, FLAC, OGG, M4A, etc.
                </p>
              </div>
            </div>

            {/* Selected File Details */}
            {selectedFile && (
              <div className="mt-5 p-4 rounded-xl bg-neutral-950/80 border border-neutral-800 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-neutral-800/80">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-neutral-800 text-emerald-400">
                      {isVideoInput ? <FileVideo className="w-5 h-5" /> : <FileAudio className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="text-sm font-semibold text-neutral-100 truncate max-w-sm sm:max-w-md">
                        {selectedFile.name}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-neutral-500 font-mono mt-0.5">
                        <span>{formatFileSize(selectedFile.size)}</span>
                        <span>•</span>
                        <span>{selectedFile.type || 'Tipo genérico'}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      fileInputRef.current?.click();
                    }}
                    className="text-xs px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors font-medium self-start sm:self-center"
                  >
                    Cambiar archivo
                  </button>
                </div>

                {/* Intelligent Hint */}
                {isVideoInput && targetType === 'audio' && (
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>
                      Archivo de video detectado. Como tienes seleccionado <strong>Audio</strong>, se extraerá la pista sonora y se exportará en <strong>.FLAC</strong>.
                    </span>
                  </div>
                )}

                {!isVideoInput && targetType === 'video' && (
                  <div className="flex items-center gap-2 p-2.5 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-300">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>
                      Archivo de audio detectado. Como tienes seleccionado <strong>Video</strong>, se generará un video <strong>.MP4</strong> con visualizador de ondas y flips visuales.
                    </span>
                  </div>
                )}

                {/* In-app Preview of the original file */}
                {fileObjectUrl && (
                  <div>
                    <span className="block text-xs font-mono text-neutral-400 mb-2">
                      Preescucha del archivo original:
                    </span>
                    <MediaPreview
                      url={fileObjectUrl}
                      type={isVideoInput ? 'video' : 'audio'}
                      title={selectedFile.name}
                    />
                  </div>
                )}
              </div>
            )}
          </section>

          {/* STEP 3: Pitch Algorithm Settings */}
          <section className="bg-neutral-900/80 border border-neutral-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-emerald-500 text-black text-xs font-bold font-mono">
                  3
                </span>
                <h2 className="text-lg font-bold text-neutral-100">
                  Algoritmo de Pitch
                </h2>
              </div>
              <span className="text-xs font-mono text-neutral-500">Opciones avanzadas</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setPitchMode('rubberband')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                  pitchMode === 'rubberband'
                    ? 'bg-neutral-800/80 border-emerald-500/70 shadow-sm'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-sm text-neutral-200">
                    Rubberband Pitch-Shift
                  </span>
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    Recomendado
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Modifica los tonos (+1, -2, +1) conservando exactamente la velocidad y tempo original del audio.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setPitchMode('resample')}
                className={`p-4 rounded-xl border text-left transition-all cursor-pointer ${
                  pitchMode === 'resample'
                    ? 'bg-neutral-800/80 border-emerald-500/70 shadow-sm'
                    : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-sm text-neutral-200">
                    Resample / Varipitch
                  </span>
                  <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-neutral-800 text-neutral-400 border border-neutral-700">
                    Clásico
                  </span>
                </div>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  Estilo tradicional de editores de video: el cambio de tono altera sutilmente la velocidad de reproducción.
                </p>
              </button>
            </div>
          </section>

          {/* Error Message if any */}
          {errorMsg && (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-red-950/40 border border-red-500/30 text-red-300 text-sm">
              <AlertCircle className="w-5 h-5 shrink-0 text-red-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Action Button: Convert */}
          <div className="pt-2">
            <button
              type="button"
              disabled={!selectedFile || isConverting}
              onClick={handleConvert}
              className={`w-full py-4 px-6 rounded-2xl font-bold text-base sm:text-lg flex items-center justify-center gap-3 transition-all duration-300 shadow-2xl ${
                !selectedFile
                  ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700/50'
                  : isConverting
                  ? 'bg-neutral-800 text-neutral-300 cursor-wait border border-neutral-700 animate-pulse'
                  : targetType === 'audio'
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-500 text-black hover:brightness-110 active:scale-[0.99] shadow-emerald-500/25 cursor-pointer'
                  : 'bg-gradient-to-r from-cyan-500 via-blue-500 to-fuchsia-500 text-white hover:brightness-110 active:scale-[0.99] shadow-cyan-500/25 cursor-pointer'
              }`}
            >
              {isConverting ? (
                <>
                  <RotateCcw className="w-5 h-5 animate-spin" />
                  <span>Procesando Preview 2 ({conversionProgress}%)...</span>
                </>
              ) : (
                <>
                  <Download className="w-5 h-5" />
                  <span>
                    Convertir a Preview 2 y Descargar como{' '}
                    <span className="font-mono underline uppercase">
                      .{targetType === 'audio' ? 'FLAC' : 'MP4'}
                    </span>
                  </span>
                </>
              )}
            </button>
          </div>

          {/* Progress Bar during conversion */}
          {isConverting && (
            <div className="p-5 rounded-2xl bg-neutral-900/90 border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-medium text-neutral-300">{progressStage}</span>
                <span className="font-mono text-emerald-400 font-bold">{conversionProgress}%</span>
              </div>
              <div className="w-full h-2.5 rounded-full bg-neutral-950 overflow-hidden p-0.5 border border-neutral-800">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-cyan-400 transition-all duration-300"
                  style={{ width: `${conversionProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Completed Job Presentation */}
          {latestJob && (
            <section className="p-6 rounded-2xl bg-neutral-900/90 border border-emerald-500/40 shadow-2xl shadow-emerald-500/10 space-y-5 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-neutral-800">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-white">
                      ¡Conversión a Preview 2 completada!
                    </h3>
                    <p className="text-xs text-neutral-400">
                      El archivo se ha descargado automáticamente en formato{' '}
                      <span className="font-mono text-emerald-400 font-bold uppercase">
                        .{latestJob.targetType === 'audio' ? 'flac' : 'mp4'}
                      </span>
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => triggerDownload(latestJob.downloadUrl, latestJob.outputName)}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 text-black font-bold text-sm hover:brightness-110 active:scale-95 transition-all shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  <span>Descargar de nuevo</span>
                </button>
              </div>

              {/* Converted specs */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                  <span className="block text-[11px] font-mono text-neutral-500 mb-0.5">Nombre</span>
                  <span className="text-xs font-semibold text-neutral-200 truncate block">
                    {latestJob.outputName}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                  <span className="block text-[11px] font-mono text-neutral-500 mb-0.5">Formato</span>
                  <span className="text-xs font-semibold text-emerald-400 font-mono">
                    {latestJob.targetType === 'audio' ? 'FLAC (Lossless)' : 'MP4 (Video H264)'}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                  <span className="block text-[11px] font-mono text-neutral-500 mb-0.5">Tamaño</span>
                  <span className="text-xs font-semibold text-neutral-200 font-mono">
                    {formatFileSize(latestJob.sizeBytes)}
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80">
                  <span className="block text-[11px] font-mono text-neutral-500 mb-0.5">Duración (4x)</span>
                  <span className="text-xs font-semibold text-neutral-200 font-mono">
                    {formatDuration(latestJob.durationSeconds)}
                  </span>
                </div>
              </div>

              {/* Embedded Player for the result */}
              <div>
                <span className="block text-xs font-mono text-neutral-400 mb-2">
                  Reproducir resultado convertido:
                </span>
                <MediaPreview
                  url={latestJob.previewUrl}
                  type={latestJob.targetType}
                  title={latestJob.outputName}
                />
              </div>
            </section>
          )}

          {/* Session History if multiple conversions */}
          {conversionHistory.length > 1 && (
            <section className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-5">
              <h3 className="text-sm font-bold text-neutral-300 mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-neutral-400" />
                <span>Historial de conversiones en esta sesión</span>
              </h3>

              <div className="space-y-2">
                {conversionHistory.map((item) => (
                  <div
                    key={item.jobId}
                    className="flex items-center justify-between p-3 rounded-xl bg-neutral-950/60 border border-neutral-800/80 text-xs"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 rounded-lg bg-neutral-800 text-neutral-400">
                        {item.targetType === 'video' ? (
                          <Video className="w-4 h-4" />
                        ) : (
                          <Music className="w-4 h-4" />
                        )}
                      </div>
                      <div>
                        <div className="font-semibold text-neutral-200">{item.outputName}</div>
                        <div className="text-neutral-500 font-mono">
                          {formatFileSize(item.sizeBytes)} • {formatDuration(item.durationSeconds)}
                        </div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => triggerDownload(item.downloadUrl, item.outputName)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-200 transition-colors cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Descargar</span>
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>

        {/* Footer */}
        <footer className="mt-16 pt-6 border-t border-neutral-800/80 text-center text-xs text-neutral-500 font-mono">
          <p>
            Convertir a preview 2 • Secuencia continua 4x: [1: Normal] + [2: Flip H, Pitch +1] + [3: Pitch -2] + [4: Flip H, Pitch +1]
          </p>
        </footer>
      </div>
    </div>
  );
}
