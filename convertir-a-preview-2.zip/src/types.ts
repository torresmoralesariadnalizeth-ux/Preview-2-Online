export type TargetType = 'audio' | 'video';
export type PitchMode = 'rubberband' | 'resample';

export interface ConvertedJob {
  jobId: string;
  outputName: string;
  targetType: TargetType;
  sizeBytes: number;
  durationSeconds: number;
  downloadUrl: string;
  previewUrl: string;
  createdAt: number;
  originalName: string;
  details?: {
    originalDuration?: number;
    hasVideo?: boolean;
    hasAudio?: boolean;
    formulaApplied?: string[];
  };
}

export interface FormulaStep {
  step: number;
  title: string;
  pitchSemitones: number;
  pitchLabel: string;
  pitchRatio: string;
  isFlipped: boolean;
  flipLabel: string;
  description: string;
  accentColor: string;
  badgeBg: string;
}
