// Web Audio API generator for previewing the Preview 2 formula

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    audioCtx = new AudioContextClass();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume();
  }
  return audioCtx;
}

export const FORMULA_STEPS = [
  {
    step: 1,
    title: 'Repetición 1',
    pitchSemitones: 0,
    pitchLabel: 'Pitch Normal (0)',
    pitchRatio: '1.000x',
    isFlipped: false,
    flipLabel: 'Sin Flip (Normal)',
    description: 'Reproducción estándar en tono y orientación original.',
    accentColor: 'text-emerald-400',
    badgeBg: 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400',
    glowColor: 'hover:border-emerald-500/50',
    freq: 440.0, // A4
  },
  {
    step: 2,
    title: 'Repetición 2',
    pitchSemitones: 1,
    pitchLabel: 'Pitch +1 semitono',
    pitchRatio: '1.059x',
    isFlipped: true,
    flipLabel: 'Flip Horizontal ↔️',
    description: 'Video invertido horizontalmente y tono elevado un semitono (+1 st).',
    accentColor: 'text-cyan-400',
    badgeBg: 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400',
    glowColor: 'hover:border-cyan-500/50',
    freq: 440.0 * Math.pow(2, 1 / 12), // ~466.16 Hz (Bb4)
  },
  {
    step: 3,
    title: 'Repetición 3',
    pitchSemitones: -2,
    pitchLabel: 'Pitch -2 semitonos',
    pitchRatio: '0.891x',
    isFlipped: false,
    flipLabel: 'Sin Flip (Normal)',
    description: 'Tono grave disminuido 2 semitonos (-2 st) con orientación original.',
    accentColor: 'text-amber-400',
    badgeBg: 'bg-amber-500/10 border-amber-500/30 text-amber-400',
    glowColor: 'hover:border-amber-500/50',
    freq: 440.0 * Math.pow(2, -2 / 12), // ~391.99 Hz (G4)
  },
  {
    step: 4,
    title: 'Repetición 4',
    pitchSemitones: 1,
    pitchLabel: 'Pitch +1 semitono',
    pitchRatio: '1.059x',
    isFlipped: true,
    flipLabel: 'Flip Horizontal ↔️',
    description: 'Video invertido horizontalmente y tono elevado un semitono (+1 st).',
    accentColor: 'text-fuchsia-400',
    badgeBg: 'bg-fuchsia-500/10 border-fuchsia-500/30 text-fuchsia-400',
    glowColor: 'hover:border-fuchsia-500/50',
    freq: 440.0 * Math.pow(2, 1 / 12), // ~466.16 Hz (Bb4)
  },
];

/**
 * Play a single step tone
 */
export function playStepTone(stepIndex: number, durationSec = 0.8) {
  try {
    const ctx = getAudioContext();
    const step = FORMULA_STEPS[stepIndex];
    if (!step) return;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    // Use a rich sawtooth with lowpass for a pleasant synth sound
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1400, ctx.currentTime);

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(step.freq, ctx.currentTime);

    gain.gain.setValueAtTime(0.2, ctx.currentTime);
    gain.gain.setValueAtTime(0.2, ctx.currentTime + durationSec - 0.02);
    gain.gain.linearRampToValueAtTime(0.001, ctx.currentTime + durationSec);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + durationSec);
  } catch (err) {
    console.warn('Audio demo error:', err);
  }
}

/**
 * Play all 4 steps sequentially without pause or fade-in/out
 */
export function playFullFormulaDemo(
  stepDuration = 0.65,
  onStepChange?: (stepIndex: number) => void,
  onFinished?: () => void
) {
  try {
    const ctx = getAudioContext();
    const startTime = ctx.currentTime + 0.05;

    FORMULA_STEPS.forEach((step, idx) => {
      const stepStartTime = startTime + idx * stepDuration;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1600, stepStartTime);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(step.freq, stepStartTime);

      // Continuous connection without gaps
      gain.gain.setValueAtTime(0.25, stepStartTime);
      // Slight tiny 5ms smoothing at boundary to avoid click, seamless join
      gain.gain.setValueAtTime(0.25, stepStartTime + stepDuration - 0.01);
      if (idx === FORMULA_STEPS.length - 1) {
        gain.gain.linearRampToValueAtTime(0.001, stepStartTime + stepDuration);
      }

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(stepStartTime);
      osc.stop(stepStartTime + stepDuration);

      if (onStepChange) {
        setTimeout(() => {
          onStepChange(idx);
        }, (idx * stepDuration + 0.05) * 1000);
      }
    });

    if (onFinished) {
      setTimeout(() => {
        onFinished();
      }, (FORMULA_STEPS.length * stepDuration + 0.1) * 1000);
    }
  } catch (err) {
    console.warn('Full formula audio demo error:', err);
  }
}

/**
 * Creates an in-memory sample WAV audio blob so the user can test immediately if they don't have an audio file
 */
export function createDemoAudioFile(): File {
  const sampleRate = 44100;
  const duration = 2.0; // 2 seconds
  const numSamples = Math.floor(sampleRate * duration);
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  // WAV header
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  writeString(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(8, 'WAVE');
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  // Synth arpeggio melody in 2 seconds (C E G C)
  const notes = [261.63, 329.63, 392.0, 523.25];
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const noteIdx = Math.floor((t / duration) * notes.length) % notes.length;
    const freq = notes[noteIdx];
    // Warm harmonic tone
    const sample =
      0.6 * Math.sin(2 * Math.PI * freq * t) +
      0.25 * Math.sin(4 * Math.PI * freq * t) +
      0.15 * Math.sin(6 * Math.PI * freq * t);
    const intSample = Math.max(-1, Math.min(1, sample)) * 0x7fff;
    view.setInt16(44 + i * 2, intSample, true);
  }

  const blob = new Blob([buffer], { type: 'audio/wav' });
  return new File([blob], 'demo_sample_audio.wav', { type: 'audio/wav' });
}
