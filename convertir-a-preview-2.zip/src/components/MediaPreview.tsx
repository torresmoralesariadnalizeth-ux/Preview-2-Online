import { useState, useRef } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, FlipHorizontal } from 'lucide-react';

interface MediaPreviewProps {
  url: string;
  type: 'audio' | 'video';
  title?: string;
  isFlipped?: boolean;
  className?: string;
}

export default function MediaPreview({
  url,
  type,
  title,
  isFlipped = false,
  className = '',
}: MediaPreviewProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [manualFlip, setManualFlip] = useState(isFlipped);
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement>(null);

  const togglePlay = () => {
    if (!mediaRef.current) return;
    if (isPlaying) {
      mediaRef.current.pause();
      setIsPlaying(false);
    } else {
      mediaRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    }
  };

  const toggleMute = () => {
    if (!mediaRef.current) return;
    mediaRef.current.muted = !mediaRef.current.muted;
    setIsMuted(mediaRef.current.muted);
  };

  return (
    <div className={`rounded-xl border border-neutral-800 bg-neutral-950/80 overflow-hidden shadow-lg ${className}`}>
      {title && (
        <div className="px-4 py-2 bg-neutral-900/80 border-b border-neutral-800 flex items-center justify-between text-xs">
          <span className="font-semibold text-neutral-300 truncate">{title}</span>
          {type === 'video' && (
            <button
              onClick={() => setManualFlip(!manualFlip)}
              className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                manualFlip ? 'bg-cyan-500/20 text-cyan-300' : 'bg-neutral-800 text-neutral-400'
              }`}
              title="Espejar visualmente para comparar"
            >
              <FlipHorizontal className="w-3 h-3" />
              <span>Flip</span>
            </button>
          )}
        </div>
      )}

      <div className="relative flex items-center justify-center bg-black/40">
        {type === 'video' ? (
          <div className="relative w-full aspect-video bg-black flex items-center justify-center overflow-hidden">
            <video
              ref={mediaRef as any}
              src={url}
              controls
              playsInline
              className={`max-h-80 w-full object-contain transition-transform duration-200 ${
                manualFlip ? 'scale-x-[-1]' : ''
              }`}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          </div>
        ) : (
          <div className="w-full p-4 flex flex-col items-center gap-3">
            <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Pista de Audio FLAC / Stream</span>
            </div>
            <audio
              ref={mediaRef as any}
              src={url}
              controls
              className="w-full h-11 accent-emerald-500"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
          </div>
        )}
      </div>
    </div>
  );
}
