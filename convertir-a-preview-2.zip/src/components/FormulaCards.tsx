import { useState } from 'react';
import { FORMULA_STEPS, playStepTone, playFullFormulaDemo } from '../utils/audioDemo';
import { Volume2, Play, Square, FlipHorizontal, HelpCircle } from 'lucide-react';

export default function FormulaCards() {
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [isPlayingDemo, setIsPlayingDemo] = useState(false);

  const handlePlayFull = () => {
    if (isPlayingDemo) return;
    setIsPlayingDemo(true);
    playFullFormulaDemo(
      0.7,
      (stepIdx) => {
        setActiveStep(stepIdx);
      },
      () => {
        setActiveStep(null);
        setIsPlayingDemo(false);
      }
    );
  };

  const handlePlaySingle = (index: number) => {
    setActiveStep(index);
    playStepTone(index, 0.8);
    setTimeout(() => {
      setActiveStep(null);
    }, 850);
  };

  return (
    <section className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 backdrop-blur-sm shadow-xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-neutral-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <HelpCircle className="w-4 h-4" />
            </span>
            <h2 className="text-xl font-bold text-neutral-100 tracking-tight">
              ¿Qué es un Preview 2?
            </h2>
          </div>
          <p className="text-sm text-neutral-400">
            Fórmula audiovisual de <strong className="text-neutral-200">4 repeticiones continuas</strong> sin pausas, sin fade-in ni fade-out.
          </p>
        </div>

        <button
          onClick={handlePlayFull}
          disabled={isPlayingDemo}
          className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-lg ${
            isPlayingDemo
              ? 'bg-neutral-800 text-neutral-400 cursor-not-allowed border border-neutral-700'
              : 'bg-gradient-to-r from-emerald-500 to-cyan-500 text-black hover:brightness-110 active:scale-95 shadow-emerald-500/20'
          }`}
          title="Escuchar la secuencia de pitches de Preview 2 con sintetizador"
        >
          {isPlayingDemo ? (
            <>
              <Square className="w-4 h-4 animate-spin" />
              <span>Reproduciendo demo...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-black" />
              <span>Escuchar fórmula de pitches</span>
            </>
          )}
        </button>
      </div>

      {/* Grid of 4 repetitions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-5">
        {FORMULA_STEPS.map((step, idx) => {
          const isCurrent = activeStep === idx;
          return (
            <div
              key={step.step}
              className={`relative flex flex-col justify-between p-4 rounded-xl border transition-all duration-200 ${
                isCurrent
                  ? 'bg-neutral-800/90 border-emerald-400/80 shadow-lg shadow-emerald-500/20 scale-[1.02]'
                  : 'bg-neutral-950/60 border-neutral-800 hover:border-neutral-700'
              }`}
            >
              {/* Header */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono font-bold tracking-wider text-neutral-400 uppercase">
                    Paso #{step.step}
                  </span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded-md font-mono font-semibold border ${step.badgeBg}`}
                  >
                    {step.pitchSemitones === 0
                      ? '0 st'
                      : step.pitchSemitones > 0
                      ? `+${step.pitchSemitones} st`
                      : `${step.pitchSemitones} st`}
                  </span>
                </div>

                <div className="text-base font-bold text-neutral-100 flex items-center gap-2 mb-2">
                  <span>{step.title}</span>
                </div>

                {/* Flip indicator */}
                <div className="flex items-center gap-2 mb-3">
                  <div
                    className={`flex items-center gap-1.5 text-xs font-semibold px-2 py-1 rounded-lg ${
                      step.isFlipped
                        ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                        : 'bg-neutral-800/80 text-neutral-400 border border-neutral-700/50'
                    }`}
                  >
                    <FlipHorizontal
                      className={`w-3.5 h-3.5 transition-transform ${
                        step.isFlipped ? 'scale-x-[-1] text-cyan-400' : ''
                      }`}
                    />
                    <span>{step.isFlipped ? 'Flip Horizontal ↔️' : 'Sin Flip'}</span>
                  </div>
                </div>

                <p className="text-xs text-neutral-400 leading-relaxed mb-4">
                  {step.description}
                </p>
              </div>

              {/* Action: Sound preview */}
              <div className="pt-3 border-t border-neutral-800/80 flex items-center justify-between">
                <span className="text-[11px] font-mono text-neutral-500">
                  Ratio: {step.pitchRatio}
                </span>

                <button
                  type="button"
                  onClick={() => handlePlaySingle(idx)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    isCurrent
                      ? 'bg-emerald-500 text-black font-semibold'
                      : 'bg-neutral-800/80 text-neutral-300 hover:bg-neutral-700 hover:text-white'
                  }`}
                  title="Escuchar el tono de esta repetición"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Tono</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 flex items-center justify-between text-xs text-neutral-500 font-mono px-2">
        <span>⚡ Enlace continuo: concat 4x en cadena directa</span>
        <span>Exporta: FLAC (si es audio) • MP4 (si es video)</span>
      </div>
    </section>
  );
}
