import express, { Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const UPLOAD_DIR = '/tmp/preview2_uploads';
const OUTPUT_DIR = '/tmp/preview2_outputs';

// Ensure directories exist
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

// Store job metadata in memory
interface JobInfo {
  id: string;
  originalName: string;
  outputName: string;
  outputPath: string;
  targetType: 'audio' | 'video';
  mimeType: string;
  sizeBytes: number;
  durationSeconds: number;
  createdAt: number;
}

const jobs = new Map<string, JobInfo>();

// Clean up files older than 2 hours
setInterval(() => {
  const twoHoursAgo = Date.now() - 2 * 60 * 60 * 1000;
  for (const [id, job] of jobs.entries()) {
    if (job.createdAt < twoHoursAgo) {
      try {
        if (fs.existsSync(job.outputPath)) {
          fs.unlinkSync(job.outputPath);
        }
      } catch (err) {
        console.error('Error cleaning up job file:', err);
      }
      jobs.delete(id);
    }
  }
}, 30 * 60 * 1000);

// Multer storage accepting ANY file without format restriction
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '';
    cb(null, `${Date.now()}-${crypto.randomUUID()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 1024 * 1024 * 1024, // 1 GB limit
  },
});

// Helper: Inspect media using ffprobe
interface ProbeResult {
  hasVideo: boolean;
  hasAudio: boolean;
  duration: number;
  videoWidth?: number;
  videoHeight?: number;
  audioSampleRate?: number;
  audioChannels?: number;
  formatName?: string;
}

function probeMedia(filePath: string): Promise<ProbeResult> {
  return new Promise((resolve) => {
    const args = [
      '-v', 'error',
      '-show_entries', 'stream=codec_type,width,height,sample_rate,channels',
      '-show_entries', 'format=duration,format_name',
      '-of', 'json',
      filePath,
    ];

    const proc = spawn('ffprobe', args);
    let stdout = '';

    proc.stdout.on('data', (d) => {
      stdout += d.toString();
    });

    proc.on('close', (code) => {
      if (code !== 0) {
        resolve({ hasVideo: false, hasAudio: true, duration: 0 });
        return;
      }

      try {
        const data = JSON.parse(stdout);
        const streams = data.streams || [];
        const format = data.format || {};
        const videoStream = streams.find((s: any) => s.codec_type === 'video');
        const audioStream = streams.find((s: any) => s.codec_type === 'audio');

        resolve({
          hasVideo: !!videoStream,
          hasAudio: !!audioStream,
          duration: parseFloat(format.duration || '0') || 0,
          videoWidth: videoStream ? parseInt(videoStream.width, 10) : undefined,
          videoHeight: videoStream ? parseInt(videoStream.height, 10) : undefined,
          audioSampleRate: audioStream ? parseInt(audioStream.sample_rate, 10) : 44100,
          audioChannels: audioStream ? parseInt(audioStream.channels, 10) : 2,
          formatName: format.format_name,
        });
      } catch (err) {
        console.error('ffprobe parse error:', err);
        resolve({ hasVideo: false, hasAudio: true, duration: 0 });
      }
    });

    proc.on('error', () => {
      resolve({ hasVideo: false, hasAudio: true, duration: 0 });
    });
  });
}

// Helper: Run FFmpeg conversion
function runFFmpeg(args: string[]): Promise<{ code: number; stderr: string }> {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', args);
    let stderr = '';

    proc.stderr.on('data', (d) => {
      stderr += d.toString();
    });

    proc.on('close', (code) => {
      if (code === 0) {
        resolve({ code: 0, stderr });
      } else {
        console.error('FFmpeg error details:', stderr);
        reject(new Error(`FFmpeg exited with code ${code}: ${stderr.slice(-500)}`));
      }
    });

    proc.on('error', (err) => {
      reject(err);
    });
  });
}

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // Health check endpoint
  app.get('/api/health', (_req: Request, res: Response) => {
    res.json({ status: 'ok', name: 'Convertir a preview 2', timestamp: Date.now() });
  });

  // Media inspection endpoint (upload or query)
  app.post('/api/inspect', upload.single('file'), async (req: Request, res: Response): Promise<void> => {
    if (!req.file) {
      res.status(400).json({ error: 'No se subió ningún archivo' });
      return;
    }

    try {
      const probe = await probeMedia(req.file.path);
      // Clean up uploaded test file
      fs.unlink(req.file.path, () => {});
      res.json({
        success: true,
        info: probe,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Error inspeccionando archivo' });
    }
  });

  // Main conversion endpoint
  app.post('/api/convert', upload.single('file'), async (req: Request, res: Response): Promise<void> => {
    if (!req.file) {
      res.status(400).json({ error: 'Debes seleccionar un archivo para convertir.' });
      return;
    }

    const inputPath = req.file.path;
    const targetType = (req.body.targetType === 'video' ? 'video' : 'audio') as 'audio' | 'video';
    const pitchMode = req.body.pitchMode === 'resample' ? 'resample' : 'rubberband';
    const originalName = req.file.originalname || 'archivo';
    const baseName = path.parse(originalName).name.replace(/[^a-zA-Z0-9_-]/g, '_') || 'audio';

    const jobId = crypto.randomUUID();

    try {
      // Step 1: Probe file
      const probe = await probeMedia(inputPath);

      // Pitch factors:
      // Rep 1: 0 semitones -> 1.0
      // Rep 2: +1 semitone -> 2^(1/12) ≈ 1.059463094
      // Rep 3: -2 semitones -> 2^(-2/12) ≈ 0.890898718
      // Rep 4: +1 semitone -> 2^(1/12) ≈ 1.059463094
      const p1 = 1.0;
      const p2 = 1.059463094359;
      const p3 = 0.890898718140;
      const p4 = 1.059463094359;

      let outputPath = '';
      let outputName = '';
      let mimeType = '';

      if (targetType === 'audio') {
        // Output FLAC
        outputName = `[preview2]_${baseName}.flac`;
        outputPath = path.join(OUTPUT_DIR, `${jobId}.flac`);
        mimeType = 'audio/flac';

        let filterComplex = '';
        if (pitchMode === 'rubberband') {
          filterComplex = [
            `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
            `[a1_in]rubberband=pitch=${p2}[a1]`,
            `[a2_in]rubberband=pitch=${p3}[a2]`,
            `[a3_in]rubberband=pitch=${p4}[a3]`,
            `[a0][a1][a2][a3]concat=n=4:v=0:a=1[outa]`,
          ].join('; ');
        } else {
          // Resample mode using asetrate & aresample
          const sr = probe.audioSampleRate || 44100;
          const r2 = Math.round(sr * p2);
          const r3 = Math.round(sr * p3);
          const r4 = Math.round(sr * p4);
          filterComplex = [
            `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
            `[a1_in]asetrate=${r2},aresample=${sr}[a1]`,
            `[a2_in]asetrate=${r3},aresample=${sr}[a2]`,
            `[a3_in]asetrate=${r4},aresample=${sr}[a3]`,
            `[a0][a1][a2][a3]concat=n=4:v=0:a=1[outa]`,
          ].join('; ');
        }

        const ffmpegArgs = [
          '-y',
          '-i', inputPath,
          '-filter_complex', filterComplex,
          '-map', '[outa]',
          '-c:a', 'flac',
          '-compression_level', '5',
          outputPath,
        ];

        await runFFmpeg(ffmpegArgs);
      } else {
        // Target: Video (Output MP4)
        outputName = `[preview2]_${baseName}.mp4`;
        outputPath = path.join(OUTPUT_DIR, `${jobId}.mp4`);
        mimeType = 'video/mp4';

        if (probe.hasVideo) {
          // Input has both video and audio (or video)
          let audioFilterPart = '';
          if (pitchMode === 'rubberband') {
            audioFilterPart = [
              `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
              `[a1_in]rubberband=pitch=${p2}[a1]`,
              `[a2_in]rubberband=pitch=${p3}[a2]`,
              `[a3_in]rubberband=pitch=${p4}[a3]`,
            ].join('; ');
          } else {
            const sr = probe.audioSampleRate || 44100;
            const r2 = Math.round(sr * p2);
            const r3 = Math.round(sr * p3);
            const r4 = Math.round(sr * p4);
            audioFilterPart = [
              `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
              `[a1_in]asetrate=${r2},aresample=${sr}[a1]`,
              `[a2_in]asetrate=${r3},aresample=${sr}[a2]`,
              `[a3_in]asetrate=${r4},aresample=${sr}[a3]`,
            ].join('; ');
          }

          const videoFilterPart = [
            `[0:v]split=4[v0][v1_in][v2][v3_in]`,
            `[v1_in]hflip[v1]`,
            `[v3_in]hflip[v3]`,
          ].join('; ');

          const concatPart = `[v0][a0][v1][a1][v2][a2][v3][a3]concat=n=4:v=1:a=1[outv][outa]`;

          const filterComplex = `${videoFilterPart}; ${audioFilterPart}; ${concatPart}`;

          const ffmpegArgs = [
            '-y',
            '-i', inputPath,
            '-filter_complex', filterComplex,
            '-map', '[outv]',
            '-map', '[outa]',
            '-c:v', 'libx264',
            '-preset', 'veryfast',
            '-crf', '22',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '192k',
            '-movflags', '+faststart',
            outputPath,
          ];

          await runFFmpeg(ffmpegArgs);
        } else {
          // Input is audio only, but user selected Video -> create video visualizer with hflip on rep 2 and 4!
          let audioFilterPart = '';
          if (pitchMode === 'rubberband') {
            audioFilterPart = [
              `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
              `[a1_in]rubberband=pitch=${p2}[a1]`,
              `[a2_in]rubberband=pitch=${p3}[a2]`,
              `[a3_in]rubberband=pitch=${p4}[a3]`,
            ].join('; ');
          } else {
            const sr = probe.audioSampleRate || 44100;
            const r2 = Math.round(sr * p2);
            const r3 = Math.round(sr * p3);
            const r4 = Math.round(sr * p4);
            audioFilterPart = [
              `[0:a]asplit=4[a0][a1_in][a2_in][a3_in]`,
              `[a1_in]asetrate=${r2},aresample=${sr}[a1]`,
              `[a2_in]asetrate=${r3},aresample=${sr}[a2]`,
              `[a3_in]asetrate=${r4},aresample=${sr}[a3]`,
            ].join('; ');
          }

          // Generate waveform visualization
          const filterComplex = [
            audioFilterPart,
            `[a0]showwaves=s=1280x720:mode=cline:colors=0x10b981[v0]`,
            `[a1]showwaves=s=1280x720:mode=cline:colors=0x06b6d4,hflip[v1]`,
            `[a2]showwaves=s=1280x720:mode=cline:colors=0xf59e0b[v2]`,
            `[a3]showwaves=s=1280x720:mode=cline:colors=0xec4899,hflip[v3]`,
            `[v0][a0][v1][a1][v2][a2][v3][a3]concat=n=4:v=1:a=1[outv][outa]`,
          ].join('; ');

          const ffmpegArgs = [
            '-y',
            '-i', inputPath,
            '-filter_complex', filterComplex,
            '-map', '[outv]',
            '-map', '[outa]',
            '-c:v', 'libx264',
            '-preset', 'veryfast',
            '-crf', '23',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '192k',
            outputPath,
          ];

          await runFFmpeg(ffmpegArgs);
        }
      }

      // Clean up uploaded file
      try {
        fs.unlinkSync(inputPath);
      } catch (e) {
        // ignore
      }

      // Check output file stats
      const stat = fs.statSync(outputPath);
      const outProbe = await probeMedia(outputPath);

      const jobInfo: JobInfo = {
        id: jobId,
        originalName,
        outputName,
        outputPath,
        targetType,
        mimeType,
        sizeBytes: stat.size,
        durationSeconds: outProbe.duration,
        createdAt: Date.now(),
      };

      jobs.set(jobId, jobInfo);

      res.json({
        success: true,
        jobId,
        outputName,
        targetType,
        sizeBytes: stat.size,
        durationSeconds: outProbe.duration,
        downloadUrl: `/api/download/${jobId}`,
        previewUrl: `/api/stream/${jobId}`,
        details: {
          originalDuration: probe.duration,
          hasVideo: probe.hasVideo,
          hasAudio: probe.hasAudio,
          formulaApplied: [
            'Repetición 1: Normal (Pitch 0, Orientación estándar)',
            'Repetición 2: Flip Horizontal ↔️ | Pitch +1 semitono',
            'Repetición 3: Sin flip | Pitch -2 semitonos',
            'Repetición 4: Flip Horizontal ↔️ | Pitch +1 semitono',
          ],
        },
      });
    } catch (err: any) {
      console.error('Conversion failed:', err);
      try {
        if (fs.existsSync(inputPath)) {
          fs.unlinkSync(inputPath);
        }
      } catch (e) {}

      res.status(500).json({
        error: `Error durante la conversión a Preview 2: ${err.message || 'Error desconocido'}`,
      });
    }
  });

  // Download endpoint (triggers save as file with Content-Disposition)
  app.get('/api/download/:jobId', (req: Request, res: Response): void => {
    const job = jobs.get(req.params.jobId);
    if (!job || !fs.existsSync(job.outputPath)) {
      res.status(404).send('Archivo no encontrado o expirado');
      return;
    }

    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(job.outputName)}"`);
    res.setHeader('Content-Type', job.mimeType);
    res.setHeader('Content-Length', job.sizeBytes);
    fs.createReadStream(job.outputPath).pipe(res);
  });

  // Stream endpoint (for inline <audio> and <video> playback)
  app.get('/api/stream/:jobId', (req: Request, res: Response): void => {
    const job = jobs.get(req.params.jobId);
    if (!job || !fs.existsSync(job.outputPath)) {
      res.status(404).send('Archivo no encontrado');
      return;
    }

    const stat = fs.statSync(job.outputPath);
    const fileSize = stat.size;
    const range = req.headers.range;

    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;
      const file = fs.createReadStream(job.outputPath, { start, end });

      res.writeHead(206, {
        'Content-Range': `bytes ${start}-${end}/${fileSize}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': job.mimeType,
      });
      file.pipe(res);
    } else {
      res.writeHead(200, {
        'Content-Length': fileSize,
        'Content-Type': job.mimeType,
      });
      fs.createReadStream(job.outputPath).pipe(res);
    }
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Preview 2] Servidor activo en http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
